# AliExpress 销冠透视 Pro v2.0 - 完整文件清单

## 📦 项目文件总览

```
aliexpress2_spy-PLUGIN/
├── 核心插件文件（必需）
│   ├── manifest.json                      ✅ 插件配置清单
│   ├── content.js                         ✅ 页面内容脚本（核心功能）
│   ├── background.js                      ✅ 后台 Service Worker
│   ├── popup.html                         ✅ 弹窗界面
│   └── popup.js                           ✅ 弹窗逻辑
│
├── 文档文件（推荐阅读）
│   ├── README.md                          📖 完整项目文档
│   ├── QUICK_START.md                     ⚡ 5 分钟快速开始
│   ├── LEMONSQUEEZY_INTEGRATION.md        💳 支付集成配置
│   ├── TECHNICAL_ARCHITECTURE.md          🏗️ 技术架构文档
│   └── FILE_INVENTORY.md                  📋 本文件清单
│
└── 可选文件
    ├── page-hook.js                       [已弃用] 原有页面钩子
    └── .gitignore                         [可选] Git 配置
```

---

## 📄 核心文件详解

### 1. **manifest.json** （插件配置清单）

**用途：** Chrome 插件的核心配置文件，定义权限、脚本、图标等

**关键配置项：**
```json
{
  "manifest_version": 3,
  "name": "AliExpress销冠透视 Pro",
  "version": "2.0.0",
  "permissions": ["storage", "activeTab", "scripting"],
  "host_permissions": [
    "https://*.aliexpress.com/*",
    "https://api.lemonsqueezy.com/*"
  ],
  "content_scripts": [
    {
      "matches": ["https://*.aliexpress.com/*"],
      "js": ["content.js"],
      "run_at": "document_end"
    }
  ]
}
```

**需要修改的地方：**
- 如果要发布到 Chrome Web Store，需要添加 icons 字段

**相关文档：** [README.md](README.md) 第 2.1 章

---

### 2. **content.js** （页面内容脚本）

**用途：** 在 AliExpress 页面中运行，注入透视按钮、处理点击事件

**核心功能：**
1. ✅ 全网盲扫 `a[href*="/item/"]`
2. ✅ 强制置顶注入按钮（zIndex: 2147483647）
3. ✅ 点击事件处理 + 事件阻止
4. ✅ 免费试用计数检查
5. ✅ 发送消息到 background.js 获取销冠数据

**关键常数（可修改）：**
```javascript
const FREE_TRIAL_LIMIT = 3;        // 免费试用次数
const SCAN_INTERVAL_MS = 2000;     // 定期扫描间隔
const MIN_LINK_WIDTH = 80;         // 最小卡片宽度
const MIN_LINK_HEIGHT = 80;        // 最小卡片高度
```

**修改指南：**
- 改变按钮样式：编辑 `BTN_STYLES` 对象
- 改变免费次数：修改 `FREE_TRIAL_LIMIT = 5`
- 改变扫描频率：修改 `SCAN_INTERVAL_MS = 3000`

**相关文档：** [TECHNICAL_ARCHITECTURE.md](TECHNICAL_ARCHITECTURE.md) 第 1 章

---

### 3. **background.js** （后台 Service Worker）

**用途：** 在后台处理消息、管理缓存、调用外部 API

**核心功能：**
1. 📨 消息路由（FETCH_SPY_DATA、UPDATE_STATS）
2. 💾 缓存管理（24 小时 TTL）
3. 🌐 后端 API 代理（可选）
4. 🎲 Mock 数据生成

**需要修改的地方：**
```javascript
// 第 12 行：配置后端 API（可选）
const DEFAULT_SPY_API_BASE = 'https://your-api.example.com';

// 或留空使用 Mock 数据
const DEFAULT_SPY_API_BASE = '';
```

**数据获取链路：**
```
请求 → 检查缓存 → 检查 API → Mock 数据 → 返回
```

**相关文档：** [TECHNICAL_ARCHITECTURE.md](TECHNICAL_ARCHITECTURE.md) 第 3 章

---

### 4. **popup.html** （弹窗界面）

**用途：** 显示用户界面（会员状态、激活输入、订阅按钮）

**关键部分：**
```html
<!-- 会员状态 -->
<span id="member-badge" class="badge badge-free">免费版</span>

<!-- 试用次数 -->
<span id="trial-remaining" class="status-value">3 / 3 次</span>

<!-- 授权码输入 -->
<input id="license-input" placeholder="粘贴授权码">

<!-- 激活按钮 -->
<button id="activate-btn">激活</button>

<!-- 订阅按钮 -->
<button id="buy-premium-btn">🛒 前往 LemonSqueezy 订阅</button>
```

**样式定制：**
- 所有样式都在 `<style>` 标签中
- 修改颜色：搜索 `#ff4742`（主颜色）或 `#2e7d32`（绿色）
- 修改宽度：搜索 `width: 360px`

**相关文档：** [QUICK_START.md](QUICK_START.md) 第 1 章

---

### 5. **popup.js** （弹窗逻辑）

**用途：** 处理弹窗事件、LemonSqueezy API 集成、用户状态管理

**关键功能：**
1. 🔐 LemonSqueezy 授权码激活
2. ✔️ 授权码验证
3. 👥 会员状态刷新
4. 📊 统计信息显示

**需要修改的地方：**
```javascript
// 第 13 行：替换为您的 LemonSqueezy 结账链接
const LEMONSQUEEZY_CHECKOUT_URL =
  'https://YOUR-STORE.lemonsqueezy.com/checkout/buy/YOUR-ID';
```

**LemonSqueezy API 端点：**
```javascript
const LEMONSQUEEZY_ACTIVATE_URL = 
  'https://api.lemonsqueezy.com/v1/licenses/activate';
const LEMONSQUEEZY_VALIDATE_URL = 
  'https://api.lemonsqueezy.com/v1/licenses/validate';
```

**相关文档：** [LEMONSQUEEZY_INTEGRATION.md](LEMONSQUEEZY_INTEGRATION.md)

---

## 📚 文档文件详解

### 1. **README.md** （完整项目文档）

**包含内容：**
- 📋 项目概述和核心功能
- 🔧 完整的架构设计说明
- 🚀 详细的部署步骤
- 📊 使用场景和流程图
- 🐛 故障排除指南
- 🛠️ 开发者扩展文档

**建议阅读人群：** 首次接触项目的开发者、产品经理、技术支持

**阅读时间：** 30-45 分钟

---

### 2. **QUICK_START.md** （快速开始指南）

**包含内容：**
- ⚡ 5 分钟快速安装步骤
- 🔑 关键配置项速览
- 🧪 测试清单（功能、兼容性、边界情况）
- 🎯 核心架构特性说明
- 🔍 调试技巧
- 📱 多设备激活说明

**建议阅读人群：** 想快速体验的用户、急赶时间的开发者

**阅读时间：** 5-10 分钟

---

### 3. **LEMONSQUEEZY_INTEGRATION.md** （支付集成指南）

**包含内容：**
- 📋 LemonSqueezy 账户设置
- 🛍️ 产品和变体配置
- 🔌 插件集成步骤
- 🧪 完整的测试流程（包括测试卡号）
- 🐛 支付相关故障排除
- 💡 商业定价和营销建议

**建议阅读人群：** 想启用付费功能的开发者、商业运营人员

**阅读时间：** 20-30 分钟

---

### 4. **TECHNICAL_ARCHITECTURE.md** （技术架构文档）

**包含内容：**
- 📐 系统架构图
- 🔄 数据流程图
- 📡 API 接口完整定义
- 💾 存储结构详解
- 🔒 安全机制
- ⚡ 性能优化技巧
- 🔧 扩展点说明
- 📊 调试信息

**建议阅读人群：** 深度开发者、系统架构师、API 使用者

**阅读时间：** 45-60 分钟

---

## 🎯 快速参考

### 常见修改

| 需求 | 文件 | 位置 | 方法 |
|------|------|------|------|
| 改变免费试用次数 | content.js + popup.js | 第 15 行 + 第 35 行 | 改变 `FREE_TRIAL_LIMIT` |
| 改变按钮样式 | content.js | 第 21-35 行 | 编辑 `BTN_STYLES` 对象 |
| 改变 LemonSqueezy 链接 | popup.js | 第 13 行 | 替换 `LEMONSQUEEZY_CHECKOUT_URL` |
| 配置后端 API | background.js | 第 12 行 | 设置 `DEFAULT_SPY_API_BASE` |
| 改变按钮颜色 | popup.html | CSS 部分 | 搜索并替换颜色代码 |
| 改变扫描频率 | content.js | 第 14 行 | 改变 `SCAN_INTERVAL_MS` |

### 常见问题快速链接

| 问题 | 文档位置 |
|------|---------|
| 怎样安装插件？ | QUICK_START.md - 第 1 步 |
| 怎样启用支付功能？ | LEMONSQUEEZY_INTEGRATION.md - 账户设置 |
| 按钮不显示怎么办？ | README.md - 故障排除 - 问题 1 |
| 点击按钮无反应怎么办？ | README.md - 故障排除 - 问题 2 |
| LemonSqueezy 激活失败？ | LEMONSQUEEZY_INTEGRATION.md - 故障排除 |
| 如何添加新的数据源？ | TECHNICAL_ARCHITECTURE.md - 扩展点 |
| API 接口文档在哪里？ | TECHNICAL_ARCHITECTURE.md - API 接口文档 |

### 关键文件大小预估

```
manifest.json               ~1 KB
content.js                ~15 KB
background.js             ~8 KB
popup.html                ~8 KB
popup.js                  ~10 KB
───────────────────────────────
总计（代码）              ~42 KB

README.md                 ~30 KB
QUICK_START.md            ~25 KB
LEMONSQUEEZY_INTEGRATION  ~35 KB
TECHNICAL_ARCHITECTURE    ~40 KB
───────────────────────────────
总计（文档）             ~130 KB

完整包体积               ~170 KB
```

---

## 🔄 文件依赖关系

```
manifest.json
    ├─ content.js
    ├─ background.js
    ├─ popup.html
    │   └─ popup.js
    │       ├─ LemonSqueezy API
    │       └─ chrome.storage.local
    └─ popup.html
        └─ 样式和 HTML 结构

content.js
    ├─ chrome.storage.local（读取 spy_user_token 和 free_trial_count）
    ├─ chrome.runtime.sendMessage（发送消息到 background.js）
    └─ DOM 操作（a[href*="/item/"]）

background.js
    ├─ chrome.storage.local（读写缓存）
    ├─ LemonSqueezy API（可选）
    ├─ 自定义后端 API（可选）
    └─ Mock 数据生成

popup.js
    ├─ chrome.storage.local（用户状态）
    ├─ chrome.tabs.create（打开结账页面）
    └─ LemonSqueezy API（激活/验证）
```

---

## 📋 部署检查清单

### 第一次部署

- [ ] 已读 QUICK_START.md
- [ ] 已将文件放入 `aliexpress2_spy-PLUGIN` 文件夹
- [ ] 已在 Chrome 中加载扩展
- [ ] 已访问 AliExpress 看到按钮
- [ ] 已点击按钮成功获取数据
- [ ] 已测试 3 次免费试用

### 启用支付功能

- [ ] 已创建 LemonSqueezy 账户
- [ ] 已创建产品和变体
- [ ] 已获取 Checkout URL
- [ ] 已在 popup.js 中更新链接
- [ ] 已使用测试卡号测试
- [ ] 已验证授权码激活流程

### 部署到生产环境

- [ ] 已在 manifest.json 中更新版本号
- [ ] 已移除所有 console.log 调试语句
- [ ] 已测试所有功能
- [ ] 已在 Chrome Web Store 创建账户
- [ ] 已打包 .crx 文件
- [ ] 已提交应用审核

---

## 🚀 版本更新记录

### v2.0.0（当前）
- ✨ 完全重构架构
- ✨ 移除混淆类名依赖
- ✨ 新增强制置顶按钮
- ✨ 新增销冠透视核心功能
- ✨ 优化 LemonSqueezy 集成
- ✨ 改进 UI/UX 设计
- 🐛 修复已知问题

### v1.1.0（前版本）
- 🔧 原始实现

---

## 📞 获取帮助

### 文档查询

1. **快速问题？** → [QUICK_START.md](QUICK_START.md)
2. **API 查询？** → [TECHNICAL_ARCHITECTURE.md](TECHNICAL_ARCHITECTURE.md)
3. **支付问题？** → [LEMONSQUEEZY_INTEGRATION.md](LEMONSQUEEZY_INTEGRATION.md)
4. **完整文档？** → [README.md](README.md)

### 代码注释

所有核心代码都有详细注释，使用以下搜索关键词快速定位：

- `[SPY]` - 页面脚本日志
- `[Background]` - 后台脚本日志
- `[Popup]` - 弹窗脚本日志
- `TODO` - 待实现功能
- `FIXME` - 已知问题

### 报告问题

如遇到问题，请：
1. 检查 Chrome 控制台是否有错误（F12）
2. 查阅相关文档中的故障排除部分
3. 参考代码注释了解实现细节
4. 查看本文件中的常见修改表

---

## ✨ 特别提示

### 发布前必读

- 📄 完整阅读 [README.md](README.md)
- 🔐 确认所有安全机制已启用
- 🧪 完整测试所有功能
- 📊 检查代码质量和性能

### 技术债清单

当前版本的已知限制：

- ⚠️ Mock 数据基于 itemId 哈希生成（非真实数据）
- ⚠️ 未实现实时消息推送（免费试用用尽时）
- ⚠️ 未实现用户反馈系统
- ⚠️ 未实现数据分析和报表导出

这些功能可在未来版本中添加。

---

**版本：** 2.0.0  
**最后更新：** 2024 年 6 月 22 日  
**总字数：** ~10,000+ 字  
**阅读时间：** 完整阅读需要 2-3 小时