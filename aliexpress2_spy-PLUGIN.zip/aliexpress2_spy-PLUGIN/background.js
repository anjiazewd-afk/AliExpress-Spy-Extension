/**
 * ====================================================
 * AliExpress 销冠透视 Pro - Background Service Worker v2.0
 * ====================================================
 * 功能：消息中转 + 可选后端 API 代理
 * ====================================================
 */

'use strict';

// ====== 配置 ======
// 部署时可将此替换为自建后端 API 根地址
// 格式：https://your-api.example.com
// 留空则仅使用本地 mock 数据
const DEFAULT_SPY_API_BASE = '';

// ====== 消息监听 ======
/**
 * 监听 content.js 发送的消息
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Background] 收到消息:', message.type);

  if (!message.type) {
    return false;
  }

  // 处理 SPY_DATA 请求（可选后端 API 代理）
  if (message.type === 'FETCH_SPY_DATA') {
    handleFetchSpyData(message.itemId, message.token, sendResponse);
    return true;  // 异步响应
  }

  // 处理统计更新
  if (message.type === 'UPDATE_STATS') {
    handleUpdateStats(message.viewedCount, message.lastAction);
    return false;
  }

  // 默认不处理
  return false;
});

// ====== 业务逻辑 ======
/**
 * 处理销冠数据获取请求
 * 支持链式降级：本地缓存 → 后端 API → Mock 数据
 */
async function handleFetchSpyData(itemId, token, sendResponse) {
  try {
    // 首先检查本地缓存
    const cached = await getProductCache(itemId);
    if (cached) {
      console.log('[Background] 使用本地缓存:', itemId);
      sendResponse({ ok: true, data: cached, source: 'cache' });
      return;
    }

    // 如果配置了后端 API，尝试从后端获取
    if (DEFAULT_SPY_API_BASE) {
      const backendData = await fetchFromBackendAPI(itemId, token);
      if (backendData) {
        console.log('[Background] 从后端 API 获取数据:', itemId);
        // 缓存后端数据
        await saveProductCache(itemId, backendData);
        sendResponse({ ok: true, data: backendData, source: 'backend' });
        return;
      }
    }

    // 降级到 Mock 数据
    console.log('[Background] 使用 Mock 数据:', itemId);
    const mockData = generateMockData(itemId);
    await saveProductCache(itemId, mockData);
    sendResponse({ ok: true, data: mockData, source: 'mock' });

  } catch (error) {
    console.error('[Background] 获取销冠数据失败:', error);
    sendResponse({ ok: false, error: error.message });
  }
}

/**
 * 从后端 API 获取销冠数据
 */
async function fetchFromBackendAPI(itemId, token) {
  const apiBase = (DEFAULT_SPY_API_BASE || '').replace(/\/$/, '');
  if (!apiBase) {
    return null;
  }

  try {
    const headers = {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };

    if (token) {
      headers['Authorization'] = 'Bearer ' + token;
    }

    const url = apiBase + '/api/product/' + encodeURIComponent(itemId);
    const response = await fetch(url, {
      method: 'GET',
      headers: headers,
      timeout: 8000
    });

    if (!response.ok) {
      console.warn('[Background] API 返回错误:', response.status);
      return null;
    }

    const json = await response.json();

    // 标准化后端返回格式
    return {
      itemId: String(itemId),
      bestseller: {
        qty: json.sales || json.soldCount || json.orders || 0,
        price: json.price || json.minPrice || 0,
        rating: json.rating || json.starRating || 0
      },
      timestamp: Date.now(),
      source: 'backend-api'
    };

  } catch (error) {
    console.warn('[Background] 后端 API 请求失败:', error);
    return null;
  }
}

/**
 * 生成 Mock 销冠数据
 * 实际部署时应调用真实后端 API
 */
function generateMockData(itemId) {
  // 基于 itemId 的哈希值生成稳定的随机数
  const hash = hashItemId(itemId);

  const mockQty = 1000 + (hash % 8000);
  const mockPrice = (2 + ((hash / 1000) % 8)).toFixed(2);
  const mockRating = (3.5 + ((hash / 10000) % 1.5)).toFixed(1);

  return {
    itemId: String(itemId),
    bestseller: {
      qty: mockQty,
      price: parseFloat(mockPrice),
      rating: parseFloat(mockRating)
    },
    timestamp: Date.now(),
    source: 'mock'
  };
}

/**
 * 简单的字符串哈希函数
 */
function hashItemId(itemId) {
  let hash = 0;
  for (let i = 0; i < itemId.length; i++) {
    const char = itemId.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;  // Convert to 32bit integer
  }
  return Math.abs(hash);
}

/**
 * 更新用户统计信息
 */
async function handleUpdateStats(viewedCount, lastAction) {
  try {
    const updateData = {};

    if (viewedCount !== undefined) {
      updateData['spy_viewed_count'] = viewedCount;
    }

    if (lastAction !== undefined) {
      updateData['spy_last_action'] = lastAction;
    }

    if (Object.keys(updateData).length > 0) {
      await chrome.storage.local.set(updateData);
      console.log('[Background] 统计信息已更新:', updateData);
    }
  } catch (error) {
    console.error('[Background] 更新统计信息失败:', error);
  }
}

// ====== 缓存管理 ======
/**
 * 获取产品缓存
 */
async function getProductCache(itemId) {
  try {
    const storageKey = 'spy_product_cache_' + itemId;
    const result = await chrome.storage.local.get(storageKey);
    const cached = result[storageKey];

    if (!cached) {
      return null;
    }

    // 检查缓存是否过期（24小时）
    const now = Date.now();
    const cacheAge = now - cached.timestamp;
    const CACHE_TTL = 24 * 60 * 60 * 1000;  // 24 hours

    if (cacheAge > CACHE_TTL) {
      console.log('[Background] 缓存已过期:', itemId);
      await chrome.storage.local.remove(storageKey);
      return null;
    }

    return cached;
  } catch (error) {
    console.error('[Background] 获取缓存失败:', error);
    return null;
  }
}

/**
 * 保存产品缓存
 */
async function saveProductCache(itemId, data) {
  try {
    const storageKey = 'spy_product_cache_' + itemId;
    const cacheData = {
      ...data,
      timestamp: Date.now()
    };

    await chrome.storage.local.set({
      [storageKey]: cacheData
    });

    console.log('[Background] 产品缓存已保存:', itemId);
  } catch (error) {
    console.error('[Background] 保存缓存失败:', error);
  }
}

// ====== 初始化 ======
console.log('[Background] Service Worker 已加载 - 销冠透视 Pro v2.0');
