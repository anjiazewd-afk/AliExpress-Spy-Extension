# AliExpress 销冠透视 Pro - 快速集成指南

## ⚡ 快速开始（5 分钟）

### 第 1 步：安装插件

```bash
# 1. 打开 Chrome 浏览器
# 2. 输入地址：chrome://extensions/
# 3. 右上角启用"开发者模式"
# 4. 点击"加载已解压的扩展程序"
# 5. 选择 aliexpress2_spy-PLUGIN 文件夹
```

### 第 2 步：测试基础功能

1. 访问 AliExpress：https://www.aliexpress.com
2. 搜索任意产品（例如：electronics）
3. 在商品卡片上看到 **"🔍 查看销冠"** 按钮
4. 点击按钮，查看销冠数据

### 第 3 步：（可选）配置 LemonSqueezy 支付

**如果您想启用付费订阅功能：**

1. 编辑 `popup.js` 第 13 行
2. 替换为您的 LemonSqueezy 结账链接
3. 完成！

---

## 🔑 关键配置项

### 1. LemonSqueezy 结账链接（popup.js）

```javascript
// 第 13 行 - 替换为您的链接
const LEMONSQUEEZY_CHECKOUT_URL =
  'https://YOUR-STORE.lemonsqueezy.com/checkout/buy/YOUR-ID';
```

**如何获取？**
- 登录 LemonSqueezy 账户
- 进入产品详情页
- 复制 Checkout URL

---

### 2. 后端 API 配置（background.js）

```javascript
// 第 12 行 - 如果您有自己的 API
const DEFAULT_SPY_API_BASE = 'https://your-api.example.com';

// 如果留空，将使用 Mock 数据
const DEFAULT_SPY_API_BASE = '';
```

**API 响应格式：**
```json
{
  "sales": 5200,
  "price": 3.5,
  "rating": 4.8
}
```

---

### 3. 免费试用次数（content.js & popup.js）

```javascript
// content.js 第 15 行
const FREE_TRIAL_LIMIT = 3;

// popup.js 第 35 行（保持一致）
const FREE_TRIAL_LIMIT = 3;
```

---

## 🧪 测试清单

### 功能测试

- [ ] **按钮显示**：访问 AliExpress 商品列表，确认看到按钮
- [ ] **按钮外观**：按钮显示为橙红色，位于卡片左上角
- [ ] **点击效果**：点击按钮，文字变为"⏳ 加载中..."
- [ ] **数据显示**：等待 2 秒，按钮变绿显示销冠数据
- [ ] **免费试用**：不登录会员，点击 3 次，第 4 次出现警告
- [ ] **会员激活**：输入授权码，激活成功后无限次使用

### 兼容性测试

- [ ] **Chrome 浏览器**：v90+
- [ ] **Firefox（可选）**：需要调整 manifest
- [ ] **多页面加载**：翻页后按钮继续显示
- [ ] **动态加载**：无限滚动加载商品，按钮自动注入

### 边界情况

- [ ] **网络离线**：显示错误提示，不删除本地数据
- [ ] **授权码过期**：显示失效提示，提示重新购买
- [ ] **API 超时**：自动降级到 Mock 数据
- [ ] **浏览器关闭**：重新打开后，数据仍保留

---

## 🎯 核心架构特性

### ✅ 不依赖混淆类名

```javascript
// ❌ 禁止（类名会动态变化）
document.querySelector('.leyui-pc-search-card-1234')

// ✅ 正确（使用 href 选择器）
document.querySelectorAll('a[href*="/item/"]')
```

### ✅ 强制置顶按钮

```javascript
// 设置商品卡片为相对定位
link.style.setProperty('position', 'relative', 'important');

// 创建绝对定位按钮（极限 zIndex）
btn.style.position = 'absolute';
btn.style.zIndex = '2147483647';  // 最高层级
btn.style.top = '10px';
btn.style.left = '10px';
btn.style.width = '120px';
btn.style.height = '28px';
```

### ✅ 事件阻止

```javascript
btn.addEventListener('click', (e) => {
  e.stopPropagation();      // 阻止事件冒泡到卡片
  e.preventDefault();        // 阻止默认链接跳转
  
  // 执行透视逻辑
  handleSpyClick();
});
```

### ✅ 数据降级链路

```
缓存 → 后端 API → Mock 数据
```

---

## 📊 使用流程图

### 免费用户流程

```
进入页面
  ↓
看到"🔍 查看销冠"按钮
  ↓
点击按钮
  ↓
检查 free_trial_count（已用次数）
  ├─ < 3 次：继续 → 消耗 1 次
  └─ ≥ 3 次：弹出警告，停止
  ↓
发送消息到 background.js
  ↓
background.js 获取销冠数据（缓存 → API → Mock）
  ↓
按钮变绿显示结果
  ├─ "📊 5.2k单 $3.5"
  └─ 标题：销冠: 5200单 | 价格: $3.5 | 评分: 4.8★
```

### 会员激活流程

```
在弹窗中粘贴授权码
  ↓
点击"激活"按钮
  ↓
popup.js 调用 LemonSqueezy API 验证
  ├─ 生成 instance ID
  └─ POST /licenses/activate
  ↓
验证成功
  ├─ 保存 token 到 storage
  └─ 显示"✅ 激活成功"
  ↓
刷新 AliExpress 页面
  ↓
content.js 检查 spy_user_token
  ├─ 存在：无限次使用
  └─ 不存在：3 次免费 + 付费激活
```

---

## 🔍 调试技巧

### 查看存储数据

在 Chrome 开发者工具（F12）中运行：

```javascript
// 查看所有存储的数据
chrome.storage.local.get(null, (data) => console.log(data));

// 查看特定字段
chrome.storage.local.get(['spy_user_token', 'free_trial_count'], (data) => {
  console.log('Token:', data.spy_user_token);
  console.log('Trial Count:', data.free_trial_count);
});

// 清空所有数据
chrome.storage.local.clear(() => console.log('Cleared'));

// 重置免费试用次数
chrome.storage.local.set({ free_trial_count: 0 });
```

### 查看控制台日志

在 Chrome 中打开 AliExpress 页面，按 F12：

```javascript
// 查看是否扫描到商品链接
// [SPY] 扫描到 48 个商品链接

// 查看按钮点击事件
// [SPY] 免费试用次数: 1/3，还剩 2 次

// 查看数据获取结果
// [Popup] 刷新 UI 状态失败
```

### 手动测试数据获取

```javascript
// 模拟调用销冠数据 API
chrome.runtime.sendMessage({
  type: 'FETCH_SPY_DATA',
  itemId: '12345678',
  token: null
}, (response) => {
  console.log('Response:', response);
});
```

---

## 🚀 部署到生产环境

### 第 1 步：打包扩展

```bash
# 进入项目目录
cd aliexpress2_spy-PLUGIN

# 使用 Chrome 打包
# chrome://extensions/ → 更多工具 → 打包扩展程序
# 选择本文件夹 → 打包
```

### 第 2 步：发布到 Chrome Web Store

1. 访问 [Chrome Web Store 开发者控制台](https://chrome.google.com/webstore/devconsole)
2. 创建新应用
3. 上传 `.crx` 文件
4. 填写信息并提交审核
5. 等待 Google 审核通过

### 第 3 步：设置自动更新

在 `manifest.json` 中添加：

```json
"update_url": "https://your-domain.com/updates.xml"
```

---

## 📱 多设备激活

### LemonSqueezy 激活限制

LemonSqueezy 允许每个授权码激活多个设备（具体数量取决于您的订阅计划）。

每次激活都会生成唯一的 `instance_id`，用于区分不同设备。

### 管理多个实例

```javascript
// 每个浏览器/设备生成不同的 instance_id
const instanceId = 'ae-spy-' + Date.now() + '-' + Math.random().toString(36);

// LemonSqueezy 会记录所有已激活的实例
// 如需查看，登录 LemonSqueezy 账户即可看到设备列表
```

---

## 💡 最佳实践

### 1. 性能优化

- 使用 `MutationObserver` 而不是 `setInterval` 轮询（已实现）
- 缓存已注入的按钮，避免重复操作（已实现）
- 使用 `debounce` 防止频繁扫描（已实现）

### 2. 安全考虑

- 不存储明文密码，仅存储 LemonSqueezy 授权码
- 使用 HTTPS 通信（LemonSqueezy API 已强制）
- 在离线状态下保留本地 token（避免误删）

### 3. 用户体验

- 给出清晰的状态提示（正在加载、成功、失败）
- 提前告知免费试用即将用尽
- 支持从弹窗快速跳转到支付页面

---

## 🎓 学习资源

- [Chrome Extension 官方文档](https://developer.chrome.com/docs/extensions/)
- [LemonSqueezy API 文档](https://docs.lemonsqueezy.com/)
- [Web Storage API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API)

---

## ❓ 常见问题

**Q: 为什么我的授权码无效？**  
A: 请确认授权码格式正确，无多余空格。如果仍无效，可能已过期，请重新购买。

**Q: 能否在多个浏览器中使用同一授权码？**  
A: 可以。每个浏览器会生成不同的 `instance_id`。

**Q: 如何重置免费试用次数？**  
A: 在浏览器开发者工具中运行 `chrome.storage.local.set({ free_trial_count: 0 })`

**Q: 插件会收集我的数据吗？**  
A: 否。所有数据仅存储在本地 `chrome.storage.local` 中。

---

**需要帮助？** 检查本文档或查看源代码注释。

**版本：** 2.0.0  
**最后更新：** 2024 年