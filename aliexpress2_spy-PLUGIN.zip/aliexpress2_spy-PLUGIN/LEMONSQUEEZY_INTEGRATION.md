# LemonSqueezy 支付集成配置指南

## 📋 目录

1. [概述](#概述)
2. [账户设置](#账户设置)
3. [产品配置](#产品配置)
4. [插件配置](#插件配置)
5. [测试流程](#测试流程)
6. [故障排除](#故障排除)

---

## 概述

本指南帮助您快速集成 **LemonSqueezy** 支付解决方案到 AliExpress 销冠透视插件中。

### 支持的功能

✅ 自动生成授权码  
✅ 支持多个计费周期（月度、年度）  
✅ 自动邮件发送授权码  
✅ 激活限制和设备管理  
✅ 订阅管理和取消  

### 定价建议

- **月度订阅**：$4.99/月（约 ¥35）
- **年度订阅**：$39.99/年（相当于 ¥280，每月 ¥23.33）
- **终身授权**：$79.99（一次性购买）

---

## 账户设置

### 第 1 步：创建 LemonSqueezy 账户

1. 访问 [LemonSqueezy 官网](https://lemonsqueezy.com)
2. 点击 "Sign Up" 注册账户
3. 填写邮箱、密码、全名
4. 选择您所在国家/地区
5. 完成邮箱验证

### 第 2 步：创建店铺

1. 登录后，点击 "Create Store"
2. 填写店铺名称（例如：AliExpress Spy）
3. 填写店铺 URL slug（例如：aliexpress-spy）
4. 选择默认货币（推荐 USD）
5. 点击 "Create"

**您的店铺链接将是：**
```
https://aliexpress-spy.lemonsqueezy.com
```

### 第 3 步：完善账户信息

1. 进入 "Settings" → "Account"
2. 填写完整的法律信息（企业/个人）
3. 填写账单地址
4. 设置税收标识（如适用）
5. 保存设置

---

## 产品配置

### 第 1 步：创建产品

1. 在 LemonSqueezy 控制面板，点击 "Products"
2. 点击 "New Product"
3. 填写产品信息：

```
产品名称：AliExpress Spy Pro
产品描述：
  实时揭示 AliExpress 同类商品销冠数据
  一键对标热销款产品
  支持 3 次免费试用

缩略图：上传您的产品图片（可选）
```

4. 点击 "Create Product"

### 第 2 步：创建变体（Variant）

变体是不同的计费方案。创建以下 3 个变体：

#### 变体 1：月度订阅

```
变体名称：Premium Monthly
计费周期：Monthly（每月）
价格：$4.99
续费周期：无限续费
```

#### 变体 2：年度订阅

```
变体名称：Premium Annual
计费周期：Annual（每年）
价格：$39.99
续费周期：无限续费
```

#### 变体 3：终身授权

```
变体名称：Premium Lifetime
计费周期：One-time（一次性）
价格：$79.99
```

### 第 3 步：启用许可证系统

1. 在产品设置中，找到 "License Key Settings"
2. 启用 "Generate license keys"
3. 配置选项：

```
License key format：自动
Key activation limit：5（每个授权码最多激活 5 个设备）
License key expiration：Never（永不过期）
```

4. 保存设置

---

## 插件配置

### 第 1 步：获取结账链接

1. 在 LemonSqueezy 中，找到您刚创建的产品
2. 进入 "Checkouts" 标签页
3. 点击 "New Checkout" 为每个变体创建结账链接

**为了简化，您可以创建一个通用结账页面：**

1. 点击 "New Checkout"
2. 选择所有变体（或只选一个推荐的）
3. 配置名称、描述和重定向 URL
4. 复制生成的 Checkout URL

**Checkout URL 格式：**
```
https://aliexpress-spy.lemonsqueezy.com/checkout/buy/a1b2c3d4-e5f6-7890-abcd-ef1234567890
```

### 第 2 步：更新插件配置

在 `popup.js` 中找到第 13 行，替换为您的结账链接：

```javascript
// 修改前
const LEMONSQUEEZY_CHECKOUT_URL =
  'https://aliexpress-spy.lemonsqueezy.com/checkout/buy/e27db694-e3c0-4a5f-996f-70f4dedeee7a';

// 修改后
const LEMONSQUEEZY_CHECKOUT_URL =
  'https://YOUR-STORE.lemonsqueezy.com/checkout/buy/YOUR-CHECKOUT-ID';
```

### 第 3 步：验证 API 端点

确认以下 API 端点可正常访问：

```javascript
// 激活 API
https://api.lemonsqueezy.com/v1/licenses/activate

// 验证 API
https://api.lemonsqueezy.com/v1/licenses/validate
```

这些是 LemonSqueezy 的公开 API，无需身份验证。

---

## 测试流程

### 测试场景 1：免费试用 3 次

```
1. 打开插件弹窗
   预期：看到"免费版"徽章，"3 / 3 次"

2. 访问 AliExpress，点击一个商品的"查看销冠"按钮
   预期：数据加载成功，显示绿色按钮

3. 点击第 2 个商品的按钮
   预期：显示"您的免费试用第 2/3 次"

4. 点击第 3 个商品的按钮
   预期：显示"您的免费试用第 3/3 次"

5. 尝试点击第 4 个商品的按钮
   预期：弹出警告"免费试用已用完，请订阅 Premium"
```

### 测试场景 2：LemonSqueezy 支付流程

```
1. 点击弹窗中的"🛒 前往 LemonSqueezy 订阅"按钮
   预期：打开 LemonSqueezy 结账页

2. 选择一个计费方案（例如 Monthly）
   预期：显示价格和产品信息

3. 填写邮箱（test@example.com）
   预期：系统要求输入支付信息

4. 使用测试卡号进行支付（见下方）
   预期：支付成功，收到授权码邮件

5. 复制授权码到插件弹窗的输入框
   预期：激活成功，显示"Premium 会员 ✓"

6. 刷新 AliExpress 页面
   预期：可以无限次点击按钮获取销冠数据
```

### 测试场景 3：授权码验证

```
1. 在弹窗中输入正确的授权码
   预期：激活成功，显示绿色确认信息

2. 输入错误的授权码
   预期：显示"授权码无效"错误

3. 关闭浏览器并重新打开
   预期：已激活的状态仍保留

4. 点击"退出登录"按钮
   预期：恢复为免费版，剩余试用次数为 0
```

### LemonSqueezy 测试支付信息

**测试模式卡号**（使用 Stripe Test 模式）：

| 场景 | 卡号 | 有效期 | CVC |
|------|------|--------|-----|
| 成功支付 | 4242 4242 4242 4242 | 任意未来日期 | 任意 3 位 |
| 支付失败 | 4000 0000 0000 0002 | 任意未来日期 | 任意 3 位 |

**测试邮箱：** 使用任意邮箱（可使用 test+timestamp@example.com）

**注意：** 需要在 LemonSqueezy 中启用"Test Mode"才能使用测试卡号

---

## 故障排除

### 问题 1：点击"订阅"按钮无反应

**原因：** 结账链接配置错误

**解决方案：**
1. 检查 `popup.js` 第 13 行的 URL 是否完整
2. 确保 URL 格式为 `https://...lemonsqueezy.com/checkout/buy/...`
3. 在浏览器控制台查看是否有错误信息
4. 手动测试链接是否可访问

### 问题 2：支付后没有收到授权码邮件

**原因 1：** 邮件进入垃圾箱

**解决方案：**
- 检查 Gmail/Outlook 的垃圾箱
- 添加 LemonSqueezy 邮箱到联系人白名单

**原因 2：** LemonSqueezy 邮件配置

**解决方案：**
1. 登录 LemonSqueezy 控制面板
2. 进入 Settings → Emails
3. 确认发件人邮箱已验证
4. 检查邮件模板是否启用

**原因 3：** 支付未成功

**解决方案：**
1. 登录 LemonSqueezy → Orders
2. 查看订单状态是否为 "Completed"
3. 如果显示 "Failed" 或 "Pending"，重新尝试支付

### 问题 3：激活时显示"授权码无效"

**原因 1：** 授权码复制错误

**解决方案：**
- 重新复制，确保没有多余空格
- 检查大小写（如果有的话）

**原因 2：** 授权码已被其他设备激活超过限制

**解决方案：**
1. 登录 LemonSqueezy 账户
2. 进入 Orders → 查找您的订单
3. 查看"Activated Instances"计数
4. 如果已达上限，需要重新购买或升级计划

**原因 3：** 网络连接问题

**解决方案：**
1. 检查网络连接
2. 禁用 VPN 或代理后重试
3. 查看浏览器控制台是否有 CORS 错误

### 问题 4：授权码已过期

**原因：** 订阅到期

**解决方案：**
1. 登录 LemonSqueezy 账户
2. 进入 Subscriptions，查看续期日期
3. 如果已过期，重新购买新的订阅
4. 使用新授权码激活

### 问题 5：同一账户多个浏览器激活

**场景：** 在 Chrome、Firefox、Edge 中都要使用

**解决方案：**
1. 每个浏览器会自动生成不同的 `instance_id`
2. LemonSqueezy 的授权码支持多设备激活（通常 5 个）
3. 在每个浏览器中粘贴同一个授权码即可
4. 如果超出限制，升级到更高的计划或购买新授权码

---

## 高级配置

### 设置自动更新通知

在 LemonSqueezy 中配置 Webhook（可选）：

1. 进入 Settings → Webhooks
2. 添加 Webhook URL（您的后端服务器）
3. 订阅事件：`subscription_updated`, `subscription_cancelled`
4. 在后端处理 Webhook，同步用户状态

### 集成 CRM

如果您使用 CRM 系统（Salesforce、HubSpot 等），可通过 Zapier 集成：

1. 创建 Zapier 账户
2. 连接 LemonSqueezy 和您的 CRM
3. 创建自动化流程（新订阅 → 添加联系人）

---

## 商业建议

### 定价策略

- **入门价**：$4.99/月（吸引新用户）
- **年度折扣**：$39.99/年（相当于 4 折）
- **终身版**：$79.99（一次性购买，约 16 个月成本）

### 营销建议

1. **试用期**：提供 3 次免费试用，降低用户转化成本
2. **邮件营销**：试用即将用完时发送订阅提醒
3. **社群反馈**：收集用户反馈，优化产品
4. **季节促销**：在黑五、双十一等节日提供优惠

### 客户支持

- 为 Premium 会员提供优先支持
- 提供视频教程和常见问题解答
- 建立社群或论坛（Discord、QQ 群等）

---

## 集成检查清单

- [ ] 在 LemonSqueezy 创建了账户
- [ ] 创建了店铺
- [ ] 创建了产品和至少一个变体
- [ ] 启用了许可证系统
- [ ] 创建了 Checkout 链接
- [ ] 在 `popup.js` 中更新了 Checkout URL
- [ ] 测试了免费试用流程
- [ ] 测试了支付流程（使用测试卡号）
- [ ] 验证了授权码激活
- [ ] 测试了多设备激活
- [ ] 验证了数据存储

---

## 参考资源

- [LemonSqueezy 官网](https://lemonsqueezy.com)
- [LemonSqueezy 文档](https://docs.lemonsqueezy.com)
- [LemonSqueezy API 文档](https://docs.lemonsqueezy.com/api)
- [Stripe 测试卡号](https://stripe.com/docs/testing)

---

**版本：** 1.0  
**最后更新：** 2024 年  
**作者：** AliExpress Spy 开发团队