# AliExpress 销冠透视 Pro - 技术架构与 API 参考

## 📐 系统架构图

```
┌─────────────────────────────────────────────────────────────┐
│                      浏览器                                   │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │                     AliExpress 页面                       │ │
│  │  ┌──────────────────────────────────────────────────┐    │ │
│  │  │  商品卡片 #1        │  商品卡片 #2  │  商品卡片 #3  │    │ │
│  │  │ ┌──────────────────┐│┌──────────────┐│┌─────────────┐│   │ │
│  │  │ │ 🔍 查看销冠    │││ 🔍 查看销冠 │││ 🔍 查看销冠│   │ │
│  │  │ │ (content.js)   │││ (injected)  │││ (injected) │   │ │
│  │  │ └──────────────────┘│└──────────────┘│└─────────────┘│   │ │
│  │  └──────────────────────────────────────────────────┘    │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                               │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  Popup 弹窗 (popup.html + popup.js)                       │ │
│  │  ┌─────────────────────────────────────────────────┐     │ │
│  │  │ 会员状态 | 免费试用 | 激活输入 | 订阅按钮      │     │ │
│  │  └─────────────────────────────────────────────────┘     │ │
│  └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
           ↑                                   ↓
      发送消息                           接收消息
    FETCH_SPY_DATA                   UPDATE_STATS
           │                               │
           ↓                               ↑
┌─────────────────────────────────────────────────────────────┐
│         Background Service Worker (background.js)            │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  消息路由器   │  缓存管理  │  API 代理  │  Mock 生成器 │ │
│  └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
           ↓
    数据获取链路：
    ┌─────────────────────────────────────────┐
    │ 缓存（chrome.storage.local）             │
    │ ↓ (无) ↓                                │
    │ 后端 API（可选）                          │
    │ ↓ (无) ↓                                │
    │ Mock 数据生成器                          │
    │ ↓ (成功) ↓                              │
    │ 返回结果给 content.js                    │
    └─────────────────────────────────────────┘
           ↓
    ┌─────────────────────────────────────────┐
    │  外部 API 调用                            │
    │  LemonSqueezy 激活/验证                  │
    │  后端 API（可选）                         │
    └─────────────────────────────────────────┘
```

---

## 🔄 数据流图

### 用户点击透视按钮

```
content.js:
  1. 监听 button.click 事件
  2. e.stopPropagation() + e.preventDefault()
  3. 检查 free_trial_count 和 spy_user_token
     ├─ 已是会员：直接请求
     ├─ 免费试用未用完：扣减 1 次 + 请求
     └─ 免费试用已用完：弹出提示，停止
  4. 提取 itemId
  5. 发送消息：chrome.runtime.sendMessage({
       type: 'FETCH_SPY_DATA',
       itemId: '12345678',
       token: 'license_key_or_null'
     })

             ↓

background.js:
  6. 接收消息，调用 handleFetchSpyData()
  7. 检查本地缓存
     ├─ 命中：返回缓存
     └─ 未命中：继续
  8. 检查后端 API 配置
     ├─ 已配置：请求后端
     │  ├─ 成功：缓存 + 返回
     │  └─ 失败：继续
     └─ 未配置：继续
  9. 生成 Mock 数据
  10. 缓存 + 返回

             ↓

content.js:
  11. 接收响应
  12. 按钮变绿，显示销冠数据
```

### 用户激活会员

```
popup.js:
  1. 用户在输入框粘贴授权码
  2. 点击"激活"按钮
  3. 检查输入是否为空
  4. 生成 instance_id（第一次）
  5. 发送 POST 请求到 LemonSqueezy API:
     POST /v1/licenses/activate
     {
       "license_key": "auth_code",
       "instance_name": "ae-spy-xxx"
     }

             ↓

  LemonSqueezy API:
  6. 验证授权码有效性
  7. 检查已激活设备数量（是否超过限制）
  8. 返回结果：
     {
       "activated": true,
       "license_key": { "status": "active" }
     }

             ↓

  popup.js:
  9. 检查激活结果
  10. 若成功：
      - 保存 token 到 chrome.storage.local
      - 显示成功提示
      - 刷新 UI（显示"Premium 会员"）
  11. 若失败：显示错误提示
```

---

## 📡 API 接口文档

### 内部消息 API

#### FETCH_SPY_DATA

**发送方：** content.js  
**接收方：** background.js  

**请求格式：**
```javascript
chrome.runtime.sendMessage({
  type: 'FETCH_SPY_DATA',
  itemId: string,        // 商品 ID
  token: string|null     // 会员 token（可选）
}, (response) => {
  // 回调处理
});
```

**响应格式：**
```javascript
{
  ok: boolean,
  data: {
    itemId: string,
    bestseller: {
      qty: number,       // 销量（件）
      price: number,     // 价格（USD）
      rating: number     // 评分（0-5）
    },
    timestamp: number,
    source: 'cache'|'backend'|'mock'
  },
  error: string|undefined
}
```

**错误情况：**
```javascript
{
  ok: false,
  error: 'Network timeout'|'API error'|'...'
}
```

---

#### UPDATE_STATS

**发送方：** content.js  
**接收方：** background.js  

**请求格式：**
```javascript
chrome.runtime.sendMessage({
  type: 'UPDATE_STATS',
  viewedCount: number,     // 今日查看商品数
  lastAction: number       // 最后操作时间戳
});
```

---

### 外部 API

#### LemonSqueezy 激活 API

**端点：** `POST https://api.lemonsqueezy.com/v1/licenses/activate`

**请求头：**
```
Content-Type: application/json
Accept: application/json
```

**请求体：**
```json
{
  "license_key": "XXXX-XXXX-XXXX-XXXX",
  "instance_name": "ae-spy-1234567890-abc123"
}
```

**成功响应（200）：**
```json
{
  "activated": true,
  "license_key": {
    "id": "lic_123456",
    "status": "active",
    "created_at": "2024-06-22T00:00:00Z",
    "instance_count": 1
  }
}
```

**错误响应（4xx/5xx）：**
```json
{
  "error": "invalid_license_key"|"too_many_instances"|"...",
  "meta": {
    "message": "详细错误信息"
  }
}
```

---

#### LemonSqueezy 验证 API

**端点：** `POST https://api.lemonsqueezy.com/v1/licenses/validate`

**请求体：**
```json
{
  "license_key": "XXXX-XXXX-XXXX-XXXX"
}
```

**成功响应：**
```json
{
  "valid": true,
  "license_key": {
    "status": "active"
  }
}
```

---

#### 自建后端 API（可选）

**端点：** `GET /api/product/{itemId}`

**请求头：**
```
Authorization: Bearer {token}
Accept: application/json
```

**成功响应（200）：**
```json
{
  "itemId": "123456789",
  "sales": 5200,
  "price": 3.5,
  "rating": 4.8
}
```

**错误响应（4xx）：**
```json
{
  "error": "product_not_found"|"unauthorized"|"..."
}
```

---

## 💾 存储结构

### chrome.storage.local 字段定义

```javascript
{
  // ============= 会员信息 =============
  "spy_user_token": {
    type: "string|null",
    description: "LemonSqueezy 授权码（用户会员状态）",
    example: "58b9f2d9-e2f5-4c2a-8e3d-7a1b9c6f4e2d",
    ttl: "无限"
  },

  // ============= 试用计数 =============
  "free_trial_count": {
    type: "number",
    description: "今日已消耗的免费试用次数",
    example: 2,
    default: 0,
    max: 3
  },

  // ============= 设备标识 =============
  "spy_instance_id": {
    type: "string",
    description: "本机唯一实例 ID（LemonSqueezy 激活用）",
    example: "ae-spy-1719014400000-a1b2c3d4",
    ttl: "永久"
  },

  // ============= 操作记录 =============
  "spy_last_action": {
    type: "number|null",
    description: "最后点击透视按钮的时间戳",
    example: 1719014400000,
    default: null
  },

  "spy_viewed_count": {
    type: "number",
    description: "今日查看的商品总数",
    example: 5,
    default: 0
  },

  // ============= 产品缓存（多个） =============
  "spy_product_cache_123456789": {
    type: "object",
    description: "单个商品的销冠数据缓存",
    ttl: "24小时",
    example: {
      "itemId": "123456789",
      "bestseller": {
        "qty": 5200,
        "price": 3.5,
        "rating": 4.8
      },
      "timestamp": 1719014400000,
      "source": "backend-api"
    }
  }
}
```

---

## 🔒 安全机制

### 1. 事件阻止

```javascript
// 阻止按钮点击冒泡到商品卡片链接
button.addEventListener('click', (e) => {
  e.stopPropagation();     // 不冒泡
  e.preventDefault();      // 不执行默认行为
}, true);                  // 捕获阶段

// 额外保护
button.addEventListener('mousedown', (e) => e.stopPropagation(), true);
button.addEventListener('mouseup', (e) => e.stopPropagation(), true);
button.addEventListener('dblclick', (e) => e.stopPropagation(), true);
```

### 2. 位置固定

```javascript
// 绝对定位确保按钮永远在最上层
link.style.setProperty('position', 'relative', 'important');
btn.style.position = 'absolute';
btn.style.zIndex = '2147483647';  // 最大 32 位整数
```

### 3. 授权码存储

```javascript
// 仅存储 LemonSqueezy 授权码，不存储密码
// 授权码通过 HTTPS 传输（LemonSqueezy API 强制）
// 本地存储采用 chrome.storage.local（加密）
```

### 4. CORS 处理

```javascript
// LemonSqueezy API 支持跨域请求（已配置 CORS）
// 后端 API 需要配置 CORS 头
// 如果遇到 CORS 问题，通过 background.js 代理
```

---

## ⚡ 性能优化

### 1. DOM 操作优化

```javascript
// ❌ 低效：频繁遍历 DOM
setInterval(() => {
  document.querySelectorAll('a[href*="/item/"]');
}, 100);

// ✅ 高效：使用 MutationObserver
new MutationObserver(() => {
  // 仅在 DOM 变化时执行
  scanAndInjectAll();
}).observe(document.documentElement, {
  childList: true,
  subtree: true
});
```

### 2. 缓存机制

```javascript
// 避免重复请求同一商品数据
const cache = new Map();

if (cache.has(itemId)) {
  return cache.get(itemId);  // O(1) 查询
}
```

### 3. 去抖动

```javascript
// 防止频繁触发扫描函数
let scanTimeout;
observer.observe(document.documentElement, {
  childList: true,
  subtree: true,
  callback: () => {
    clearTimeout(scanTimeout);
    scanTimeout = setTimeout(() => {
      scanAndInjectAll();
    }, 300);  // 延迟 300ms 执行
  }
});
```

---

## 🔧 扩展点

### 1. 添加新的数据源

在 `background.js` 中修改 `handleFetchSpyData()` 函数的降级链路：

```javascript
async function handleFetchSpyData(itemId, token, sendResponse) {
  // 原有链路：缓存 → 后端 → Mock
  
  // 可添加新源，例如：
  // 缓存 → 第三方 API → 后端 → 爬虫数据 → Mock
}
```

### 2. 自定义按钮样式

在 `content.js` 的 `BTN_STYLES` 对象中修改：

```javascript
const BTN_STYLES = {
  position: 'absolute',
  top: '10px',
  left: '10px',
  width: '120px',
  height: '28px',
  // 修改颜色、字体等...
  backgroundColor: '#your-color',
  fontFamily: 'your-font'
};
```

### 3. 添加新的会员等级

在 `content.js` 和 `popup.js` 中添加新的权限检查：

```javascript
// 例如：添加"企业版"，无限次 + 导出功能
if (userType === 'enterprise') {
  enableExportFeature();
}
```

---

## 📊 调试信息

### 启用详细日志

在 `content.js` 开头添加：

```javascript
const DEBUG = true;
const log = DEBUG ? console.log : () => {};

log('[SPY] 调试日志已启用');
```

### 常见日志信息

```javascript
// content.js
[SPY] 扫描到 48 个商品链接
[SPY] 注入按钮到商品卡片
[SPY] 免费试用次数: 1/3，还剩 2 次
[SPY] 获取销冠数据成功
[SPY] 提取卡片信息错误

// background.js
[Background] 收到消息: FETCH_SPY_DATA
[Background] 使用本地缓存: 123456
[Background] 从后端 API 获取数据: 123456
[Background] 产品缓存已保存: 123456

// popup.js
[Popup] 初始化销冠透视弹窗 v2.0
[Popup] 刷新 UI 状态失败
[Popup] 激活错误: ...
```

---

## 🚀 部署检查清单

### 代码质量检查

- [ ] 无 console.error 输出
- [ ] 无未捕获的 Promise 异常
- [ ] 无 XSS 漏洞（不使用 innerHTML）
- [ ] 无内存泄漏（及时释放 Event Listener）

### 功能验证

- [ ] 按钮正确注入到所有商品卡片
- [ ] 点击按钮不会跳转到商品页面
- [ ] 数据获取成功率 > 95%
- [ ] 缓存工作正常
- [ ] 会员激活流程完整

### 兼容性测试

- [ ] Chrome 90+
- [ ] Chrome 移动版（安卓）
- [ ] 多语言 AliExpress 域名
- [ ] 不同网络条件

### 安全审计

- [ ] 未存储用户个人信息
- [ ] HTTPS 通信
- [ ] 授权码不在 localStorage 暴露
- [ ] 无跨站脚本注入

---

## 📞 技术支持联系方式

- 📧 Email: support@aliexpress-spy.com
- 💬 Discord: https://discord.gg/aliexpress-spy
- 🐛 Bug Report: https://github.com/aliexpress-spy/issues

---

**版本：** 2.0.0  
**最后更新：** 2024 年  
**维护者：** AliExpress Spy 开发团队