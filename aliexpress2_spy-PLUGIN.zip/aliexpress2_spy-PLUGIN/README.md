# AliExpress 销冠透视 Pro v2.0

## 🎯 项目概述

**销冠透视 Pro** 是一个专业的 Chrome 插件，用于实时揭示 AliExpress 商品列表页面中的同类商品销冠数据。通过一键点击，用户可以快速对标热销款产品，获取销量、价格、评分等关键商业数据。

### 🌟 核心功能

✅ **全网盲扫商品链接**  
- 使用 `a[href*="/item/"]` 选择器，不依赖混淆类名  
- 自动检测新加载的商品卡片，动态注入透视按钮

✅ **强制置顶透视按钮**  
- 绝对定位（zIndex: 2147483647）  
- 固定宽高 120px × 28px，左上角放置（top: 10px; left: 10px;）  
- 完全防止被页面元素遮挡

✅ **同类销冠核心逻辑**  
- 提取商品卡片内的图片链接或标题  
- 异步请求销冠数据（支持 Mock、后端 API）  
- 实时更新按钮显示销量、价格、评分

✅ **试用与订阅闭环**  
- 免费用户：3 次试用机会  
- 会员用户：无限次透视  
- LemonSqueezy 支付集成，授权码激活

## 📂 文件结构

```
aliexpress2_spy-PLUGIN/
├── manifest.json          # 插件配置清单
├── content.js             # 页面内容脚本（核心逻辑）
├── background.js          # 后台 Service Worker
├── popup.html             # 弹窗界面（会员管理）
├── popup.js               # 弹窗逻辑（LemonSqueezy 集成）
├── page-hook.js           # [可选] 页面主脚本
└── README.md              # 本文档
```

## 🔧 架构设计

### 1. content.js（核心页面脚本）

#### 关键架构原则：

**❌ 绝禁依赖混淆类名**
```javascript
// ❌ 禁止：AliExpress 类名动态变化
document.querySelector('.dynamicClassName123')

// ✅ 正确：使用 href 属性锚定
document.querySelectorAll('a[href*="/item/"]')
```

**✅ 全网盲扫**
```javascript
// 扫描所有商品链接（无论在列表的哪个位置）
const links = document.querySelectorAll('a[href*="/item/"]');
```

**✅ 强制置顶注入按钮**
```javascript
link.style.setProperty('position', 'relative', 'important');

const btn = document.createElement('button');
btn.style.position = 'absolute';
btn.style.zIndex = '2147483647';  // 极限 zIndex
btn.style.top = '10px';
btn.style.left = '10px';
btn.style.width = '120px';
btn.style.height = '28px';
link.appendChild(btn);
```

#### 销冠透视核心流程：

```javascript
// 1. 点击按钮
button.addEventListener('click', async (e) => {
  e.stopPropagation();      // 阻止冒泡
  e.preventDefault();        // 阻止默认跳转
  
  // 2. 检查免费次数
  const allowed = checkFreeTrial();
  if (!allowed) {
    alert('免费次数已用完，请订阅 Premium');
    return;
  }
  
  // 3. 获取销冠数据
  const data = await fetchBestSeller(itemId);
  
  // 4. 更新按钮显示
  button.textContent = `📊 ${data.bestseller.qty}单 $${data.bestseller.price}`;
  button.style.backgroundColor = '#2e7d32';  // 绿色
});
```

#### 数据获取链路（降级策略）：

```
用户点击 → 检查缓存 → 后端 API → Mock 数据 → 显示结果
```

### 2. popup.html & popup.js（会员管理）

#### 三层用户体验：

**状态 1：免费版本**
- 显示 "免费版" 徽章
- 显示剩余试用次数（0-3）
- 试用进度条

**状态 2：Premium 会员**
- 显示 "Premium 会员 ✓" 徽章
- 显示 "∞ 无限次"
- 隐藏购买按钮，显示退出按钮

**状态 3：激活流程**
```
粘贴授权码 → 验证 LemonSqueezy API → 保存 token → 刷新页面即可使用
```

### 3. background.js（后台 Service Worker）

#### 消息处理：

```javascript
// content.js 发送消息
chrome.runtime.sendMessage({
  type: 'FETCH_SPY_DATA',
  itemId: '12345678',
  token: 'license_key'
}, (response) => {
  console.log(response.data);
});
```

#### 数据源优先级：

1. **本地缓存**（24小时 TTL）
2. **后端 API**（如果配置）
3. **Mock 数据**（生产环保证）

## 🚀 部署步骤

### 第 1 步：安装插件

1. 打开 Chrome，访问 `chrome://extensions/`
2. 启用 "开发者模式"（右上角）
3. 点击 "加载已解压的扩展程序"
4. 选择 `aliexpress2_spy-PLUGIN` 文件夹
5. 完成！插件图标将出现在浏览器右上角

### 第 2 步：配置 LemonSqueezy（可选但推荐）

#### 2.1 创建 LemonSqueezy 店铺

1. 访问 [LemonSqueezy](https://lemonsqueezy.com)
2. 注册账户并创建店铺
3. 创建新产品（例如 "AliExpress Spy Premium"）
4. 设置价格（推荐 $4.99/月）

#### 2.2 获取结账链接

1. 进入产品详情页
2. 复制 "Checkout URL"（格式：`https://<store>.lemonsqueezy.com/checkout/buy/<id>`）

#### 2.3 更新插件配置

在 [popup.js](popup.js) 中替换第 13 行：

```javascript
// 修改前
const LEMONSQUEEZY_CHECKOUT_URL =
  'https://aliexpress-spy.lemonsqueezy.com/checkout/buy/e27db694-e3c0-4a5f-996f-70f4dedeee7a';

// 修改后（替换为您的链接）
const LEMONSQUEEZY_CHECKOUT_URL =
  'https://YOUR-STORE.lemonsqueezy.com/checkout/buy/YOUR-ID';
```

### 第 3 步：配置后端 API（可选）

如果您有自建的销冠数据 API，可在 [background.js](background.js) 中配置：

```javascript
// 修改第 12 行
const DEFAULT_SPY_API_BASE = 'https://your-api.example.com';

// API 应该返回以下格式：
{
  "sales": 5200,
  "price": 3.5,
  "rating": 4.8
}
```

### 第 4 步：测试插件

1. 访问 [AliExpress 搜索页](https://www.aliexpress.com/wholesale?SearchText=electronics)
2. 在商品卡片上看到 "🔍 查看销冠" 按钮
3. 点击按钮测试数据获取

## 📊 使用场景

### 场景 1：免费用户试用
```
用户进入页面 → 看到"查看销冠"按钮 → 点击按钮（第1次）→ 消耗1次试用机会
→ 按钮变绿显示销冠数据 → 点击另一个商品（第2次）→ 还剩1次
→ 点击第3个商品（第3次）→ 提示"免费次数已用完，请订阅 Premium"
```

### 场景 2：会员用户
```
用户激活 Premium 会员 → 进入 AliExpress 页面
→ 弹窗显示"Premium 会员 ✓" → 无限次点击按钮获取销冠数据
```

### 场景 3：LemonSqueezy 支付流程
```
用户点击"🛒 前往 LemonSqueezy 订阅" → 跳转到支付页面
→ 完成支付 → LemonSqueezy 发送授权码到邮箱
→ 用户复制授权码 → 在弹窗中粘贴并点击"激活" → 验证成功 → 激活会员
```

## 🔐 存储结构

所有数据保存在 `chrome.storage.local`：

```javascript
{
  // 会员 Token（空=免费版）
  "spy_user_token": "license_key_xxx",
  
  // 免费试用计数
  "free_trial_count": 2,
  
  // 实例 ID（LemonSqueezy 激活用）
  "spy_instance_id": "ae-spy-1234567890-abc123",
  
  // 最后操作时间戳
  "spy_last_action": "1719014400000",
  
  // 今日查看商品数
  "spy_viewed_count": 5,
  
  // 产品缓存（24小时过期）
  "spy_product_cache_123456": {
    "itemId": "123456",
    "bestseller": { "qty": 5200, "price": 3.5, "rating": 4.8 },
    "timestamp": 1719014400000
  }
}
```

## 🎨 UI 效果说明

### 按钮状态变化

**初始状态（灰色）**
```
┌─────────────────┐
│ 🔍 查看销冠    │  (background: #ff4742)
└─────────────────┘
```

**加载中（深灰色）**
```
┌─────────────────┐
│ ⏳ 加载中...   │  (background: #757575)
└─────────────────┘
```

**成功（绿色）**
```
┌──────────────────┐
│ 📊 5.2k单 $3.5 │  (background: #2e7d32, width: 110px)
└──────────────────┘
```

**错误（红色）**
```
┌─────────────────┐
│ ❌ 获取数据失败 │  (background: #d32f2f)
└─────────────────┘
```

## 🐛 故障排除

### 问题 1：按钮不显示

**检查清单：**
- [ ] 确认进入的是 AliExpress 官方商品列表页面
- [ ] 在浏览器控制台检查是否有 JS 错误
- [ ] 尝试刷新页面（Ctrl+F5）
- [ ] 检查插件是否已启用（chrome://extensions/）

**诊断命令：**
```javascript
// 在页面控制台运行
document.querySelectorAll('a[href*="/item/"]').length  // 应该 > 0
```

### 问题 2：点击按钮无反应

**检查清单：**
- [ ] 检查是否连接到互联网
- [ ] 查看浏览器控制台是否有错误
- [ ] 尝试退出重新登录会员

### 问题 3：LemonSqueezy 激活失败

**常见原因：**
- 授权码已过期（LemonSqueezy 会重新发送）
- 授权码已在其他设备上激活（LemonSqueezy 限制）
- 网络连接问题

**解决方案：**
1. 确认授权码是否正确复制（无空格）
2. 检查网络连接
3. 联系 LemonSqueezy 支持

## 🛠️ 开发者文档

### 添加新的数据源

在 `background.js` 中修改 `fetchFromBackendAPI` 函数：

```javascript
async function fetchFromBackendAPI(itemId, token) {
  // 您的自定义数据获取逻辑
  const response = await fetch(`https://your-api.com/product/${itemId}`);
  const json = await response.json();
  
  return {
    itemId: String(itemId),
    bestseller: {
      qty: json.your_field_sales,
      price: json.your_field_price,
      rating: json.your_field_rating
    },
    timestamp: Date.now(),
    source: 'your-api'
  };
}
```

### 修改免费试用次数

在 `content.js` 第 15 行修改：

```javascript
const FREE_TRIAL_LIMIT = 5;  // 改为 5 次
```

同时在 `popup.js` 第 35 行也要修改：

```javascript
const FREE_TRIAL_LIMIT = 5;
```

## 📝 API 契约

### LemonSqueezy 激活 API

**端点：** `https://api.lemonsqueezy.com/v1/licenses/activate`  
**方法：** `POST`  
**请求体：**
```json
{
  "license_key": "your_license_key",
  "instance_name": "ae-spy-unique-id"
}
```

**成功响应：**
```json
{
  "activated": true,
  "license_key": { "status": "active" }
}
```

### 自建后端 API 契约

**端点：** `GET /api/product/{itemId}`  
**授权头：** `Authorization: Bearer {token}`

**响应格式：**
```json
{
  "sales": 5200,
  "price": 3.5,
  "rating": 4.8
}
```

## 📞 技术支持

- **问题反馈：** 请检查本文档的"故障排除"部分
- **功能建议：** 欢迎提出改进意见
- **紧急问题：** 检查 `chrome://extensions/` 中的错误日志

## 📄 许可证

本插件仅供学习研究使用。商业使用需获得相应授权。

## 🎉 更新日志

### v2.0.0（当前版本）
- ✨ 完全重构架构，移除混淆类名依赖
- ✨ 新增强制置顶按钮机制（zIndex: 2147483647）
- ✨ 新增同类销冠透视核心功能
- ✨ 优化 LemonSqueezy 集成
- ✨ 改进 UI/UX 设计
- 🐛 修复各种已知问题

---

**版本：** 2.0.0  
**最后更新：** 2024 年  
**作者：** AliExpress Spy 开发团队