/**
 * ====================================================
 * AliExpress 销冠透视 Pro - Popup Script v2.0
 * ====================================================
 * 功能：会员状态管理 + LemonSqueezy 订阅集成
 * ====================================================
 */

(function () {
  'use strict';

  // ====== LemonSqueezy 配置（部署时请替换） ======
  // 配置格式：https://<your-store>.lemonsqueezy.com/checkout/buy/<checkout-id>
  const LEMONSQUEEZY_CHECKOUT_URL =
    'https://aliexpress-spy.lemonsqueezy.com/checkout/buy/e27db694-e3c0-4a5f-996f-70f4dedeee7a';

  // LemonSqueezy API 端点
  const LEMONSQUEEZY_ACTIVATE_URL = 'https://api.lemonsqueezy.com/v1/licenses/activate';
  const LEMONSQUEEZY_VALIDATE_URL = 'https://api.lemonsqueezy.com/v1/licenses/validate';

  // ====== 常数配置 ======
  const FREE_TRIAL_LIMIT = 3;
  const STORAGE_KEYS = {
    userToken: 'spy_user_token',
    freeTrialCount: 'free_trial_count',
    instanceId: 'spy_instance_id',
    lastAction: 'spy_last_action',
    viewedCount: 'spy_viewed_count'
  };

  // ====== DOM 元素选择器 ======
  const $ = (id) => document.getElementById(id);

  const memberBadge = $('member-badge');
  const trialRemaining = $('trial-remaining');
  const trialBar = $('trial-bar');
  const licenseInput = $('license-input');
  const activateBtn = $('activate-btn');
  const buyBtn = $('buy-premium-btn');
  const logoutBtn = $('logout-btn');
  const statusMessage = $('status-message');
  const statsViewed = $('stats-viewed');
  const statsLastAction = $('stats-last-action');

  // ====== Storage Helper Functions ======
  /**
   * Promise 包装 chrome.storage.local.get
   */
  function storageGet(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.get(keys, (result) => {
        if (chrome.runtime.lastError) {
          console.error('[Popup] Storage get error:', chrome.runtime.lastError);
          resolve({});
        } else {
          resolve(result);
        }
      });
    });
  }

  /**
   * Promise 包装 chrome.storage.local.set
   */
  function storageSet(data) {
    return new Promise((resolve) => {
      chrome.storage.local.set(data, () => {
        if (chrome.runtime.lastError) {
          console.error('[Popup] Storage set error:', chrome.runtime.lastError);
        }
        resolve();
      });
    });
  }

  /**
   * Promise 包装 chrome.storage.local.remove
   */
  function storageRemove(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.remove(keys, () => {
        if (chrome.runtime.lastError) {
          console.error('[Popup] Storage remove error:', chrome.runtime.lastError);
        }
        resolve();
      });
    });
  }

  // ====== 实例 ID 管理 ======
  /**
   * 获取或创建本机唯一实例 ID
   * LemonSqueezy 激活时需要
   */
  async function getOrCreateInstanceId() {
    const stored = await storageGet({ [STORAGE_KEYS.instanceId]: null });

    if (stored[STORAGE_KEYS.instanceId]) {
      return stored[STORAGE_KEYS.instanceId];
    }

    // 生成新的实例 ID
    const instanceId = 'ae-spy-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    await storageSet({ [STORAGE_KEYS.instanceId]: instanceId });

    return instanceId;
  }

  // ====== UI 状态管理 ======
  /**
   * 显示状态消息
   */
  function showStatus(message, type = 'info') {
    statusMessage.textContent = message;
    statusMessage.className = 'status-message show ' + type;

    // 自动隐藏成功和错误消息
    if (type !== 'info') {
      setTimeout(() => {
        statusMessage.classList.remove('show');
      }, 5000);
    }
  }

  /**
   * 隐藏状态消息
   */
  function hideStatus() {
    statusMessage.classList.remove('show');
  }

  /**
   * 掩码授权码（隐私保护）
   */
  function maskLicense(license) {
    if (!license || license.length < 8) return '****';
    return license.slice(0, 4) + '****' + license.slice(-4);
  }

  /**
   * 更新 UI 显示用户状态
   */
  async function refreshUIStatus() {
    try {
      const data = await storageGet({
        [STORAGE_KEYS.userToken]: null,
        [STORAGE_KEYS.freeTrialCount]: 0,
        [STORAGE_KEYS.viewedCount]: 0,
        [STORAGE_KEYS.lastAction]: null
      });

      const userToken = data[STORAGE_KEYS.userToken];
      const trialCount = Number(data[STORAGE_KEYS.freeTrialCount]) || 0;
      const viewedCount = Number(data[STORAGE_KEYS.viewedCount]) || 0;
      const lastAction = data[STORAGE_KEYS.lastAction];

      // ---- 会员状态 ----
      if (userToken) {
        // Premium 会员
        memberBadge.textContent = 'Premium 会员 ✓';
        memberBadge.className = 'badge badge-premium';
        trialRemaining.textContent = '∞ 无限次';
        trialBar.style.width = '100%';
        trialBar.style.background = 'linear-gradient(90deg, #2e7d32, #43a047)';

        licenseInput.value = maskLicense(userToken);
        licenseInput.disabled = true;
        activateBtn.disabled = true;
        buyBtn.style.display = 'none';
        logoutBtn.classList.add('visible');

        showStatus('✅ 高级会员已激活，全站无限次透视已解锁！', 'success');
      } else {
        // 免费版
        memberBadge.textContent = '免费版';
        memberBadge.className = 'badge badge-free';

        const remaining = Math.max(0, FREE_TRIAL_LIMIT - trialCount);
        trialRemaining.textContent = `${remaining} / ${FREE_TRIAL_LIMIT} 次`;

        // 试用进度条
        const percentage = ((FREE_TRIAL_LIMIT - remaining) / FREE_TRIAL_LIMIT) * 100;
        trialBar.style.width = percentage + '%';

        licenseInput.value = '';
        licenseInput.disabled = false;
        activateBtn.disabled = false;
        buyBtn.style.display = 'block';
        logoutBtn.classList.remove('visible');

        if (remaining <= 0) {
          showStatus('⚠️ 免费试用已用完，请订阅 Premium 会员解锁全站无限次透视', 'error');
        } else {
          hideStatus();
        }
      }

      // ---- 统计信息 ----
      statsViewed.textContent = viewedCount + ' 个';

      if (lastAction) {
        const date = new Date(parseInt(lastAction));
        const timeStr = date.toLocaleTimeString('zh-CN');
        statsLastAction.textContent = timeStr;
      } else {
        statsLastAction.textContent = '暂无操作';
      }

    } catch (error) {
      console.error('[Popup] 刷新 UI 状态失败:', error);
    }
  }

  // ====== LemonSqueezy 集成 ======
  /**
   * 调用 LemonSqueezy API 激活授权码
   */
  async function activateLicenseWithLemonSqueezy(licenseKey) {
    try {
      const instanceId = await getOrCreateInstanceId();

      const response = await fetch(LEMONSQUEEZY_ACTIVATE_URL, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          license_key: licenseKey,
          instance_name: instanceId
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const json = await response.json();
      return json;
    } catch (error) {
      console.error('[Popup] LemonSqueezy 激活失败:', error);
      throw error;
    }
  }

  /**
   * 验证已存储的授权码是否仍然有效
   */
  async function validateLicenseWithLemonSqueezy(licenseKey) {
    try {
      const response = await fetch(LEMONSQUEEZY_VALIDATE_URL, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          license_key: licenseKey
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('[Popup] LemonSqueezy 验证失败:', error);
      return null;
    }
  }

  // ====== 事件处理 ======
  /**
   * 激活按钮点击处理
   */
  async function handleActivate() {
    const rawInput = licenseInput.value.trim();

    if (!rawInput) {
      showStatus('❌ 请输入 LemonSqueezy 授权码', 'error');
      return;
    }

    activateBtn.disabled = true;
    showStatus('⏳ 正在验证授权码...', 'info');

    try {
      const result = await activateLicenseWithLemonSqueezy(rawInput);

      // 检查激活结果
      const isActivated =
        result.activated === true ||
        result.license_key?.status === 'active' ||
        result.meta?.valid === true;

      if (isActivated) {
        // 激活成功，保存 token
        await storageSet({
          [STORAGE_KEYS.userToken]: rawInput,
          [STORAGE_KEYS.freeTrialCount]: 0  // 重置试用计数
        });

        showStatus('🎉 激活成功！请刷新 AliExpress 页面开始享受无限透视', 'success');
        await refreshUIStatus();
        return;
      }

      // 激活失败
      const errorMsg =
        result.error ||
        result.meta?.message ||
        '授权码无效或已被其他设备占用。请检查后重试或联系支持。';

      showStatus('❌ ' + errorMsg, 'error');

    } catch (err) {
      console.error('[Popup] 激活错误:', err);
      showStatus('❌ 网络错误，请检查网络连接后重试', 'error');
    } finally {
      activateBtn.disabled = false;
    }
  }

  /**
   * 退出登录按钮处理
   */
  async function handleLogout() {
    const confirm = window.confirm('确认退出登录？退出后将恢复为免费版。');
    if (!confirm) return;

    try {
      await storageRemove([STORAGE_KEYS.userToken]);
      licenseInput.value = '';
      showStatus('✅ 已退出登录，恢复为免费版', 'success');
      await refreshUIStatus();
    } catch (error) {
      console.error('[Popup] 退出登录失败:', error);
      showStatus('❌ 退出登录失败', 'error');
    }
  }

  /**
   * 购买按钮处理
   */
  function handleBuy() {
    // 打开 LemonSqueezy 结账页面
    chrome.tabs.create({
      url: LEMONSQUEEZY_CHECKOUT_URL,
      active: true
    });

    showStatus('📱 已打开 LemonSqueezy 订阅页面，请按照提示完成支付', 'info');
  }

  /**
   * 启动时静默验证现有 token
   */
  async function silentValidateToken() {
    try {
      const data = await storageGet({ [STORAGE_KEYS.userToken]: null });
      const token = data[STORAGE_KEYS.userToken];

      if (!token) {
        return;  // 无 token，无需验证
      }

      // 尝试验证 token 有效性
      const validationResult = await validateLicenseWithLemonSqueezy(token);

      if (validationResult) {
        const isValid =
          validationResult.valid === true ||
          validationResult.license_key?.status === 'active' ||
          validationResult.meta?.valid === true;

        if (!isValid) {
          // Token 已失效，删除本地存储
          console.log('[Popup] Token 已过期，删除本地存储');
          await storageRemove([STORAGE_KEYS.userToken]);
        }
      }
    } catch (error) {
      // 网络离线时保留本地 token，避免意外删除
      console.warn('[Popup] 离线状态，保留本地 token:', error);
    }
  }

  /**
   * 监听授权码输入框回车键
   */
  function handleLicenseInputKeydown(e) {
    if (e.key === 'Enter') {
      handleActivate();
    }
  }

  // ====== 事件绑定 ======
  activateBtn.addEventListener('click', handleActivate);
  buyBtn.addEventListener('click', handleBuy);
  logoutBtn.addEventListener('click', handleLogout);
  licenseInput.addEventListener('keydown', handleLicenseInputKeydown);

  // ====== 初始化 ======
  (async function init() {
    console.log('[Popup] 初始化销冠透视弹窗 v2.0');

    // 验证现有 token
    await silentValidateToken();

    // 刷新 UI
    await refreshUIStatus();
  })();
})();
