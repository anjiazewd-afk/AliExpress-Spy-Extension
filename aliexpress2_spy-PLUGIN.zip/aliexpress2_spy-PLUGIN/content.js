/**
 * ====================================================
 * AliExpress 销冠透视 Pro - Content Script v2.0
 * ====================================================
 * 核心架构原则：
 * 1. 绝不使用混淆类名选择器（Class 名）
 * 2. 纯粹锚定：a[href*="/item/"] 全网盲扫
 * 3. 强制置顶：zIndex: 2147483647 的绝对定位按钮
 * 4. 销冠透视：提取卡片数据 + Mock 销冠返回
 * 5. 试用限制：3 次免费 + 会员无限
 * ====================================================
 */

(function () {
  'use strict';

  // ====== 配置常数 ======
  const SPY_BTN_CLASS = 'ae-spy-btn-injected-v2';
  const SPY_MARKED_ATTR = 'data-ae-spy-marked';
  const FREE_TRIAL_LIMIT = 3;
  const SCAN_INTERVAL_MS = 2000;
  const MIN_LINK_WIDTH = 80;
  const MIN_LINK_HEIGHT = 80;

  // ====== 产品缓存 ======
  const productDataCache = new Map();

  // ====== 按钮样式（绝对定位 + 极限 zIndex） ======
  const BTN_STYLES = {
    position: 'absolute',
    top: '10px',
    left: '10px',
    width: '120px',
    height: '28px',
    zIndex: '2147483647',
    backgroundColor: '#ff4742',
    color: '#ffffff',
    border: 'none',
    borderRadius: '3px',
    cursor: 'pointer',
    fontSize: '11px',
    fontWeight: '600',
    lineHeight: '28px',
    textAlign: 'center',
    padding: '0 6px',
    margin: '0',
    boxSizing: 'border-box',
    boxShadow: '0 3px 8px rgba(0, 0, 0, 0.4)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    visibility: 'visible',
    opacity: '1',
    pointerEvents: 'auto',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    fontFamily: '"Segoe UI", Tahoma, sans-serif'
  };

  /**
   * 从商品卡片提取基础信息
   * 不依赖任何 Class 名，仅基于 DOM 结构
   */
  function extractCardInfo(link) {
    try {
      const cardInfo = {
        title: '',
        imageUrl: '',
        priceText: ''
      };

      // 查找卡片容器（向上遍历 10 层）
      let container = link;
      for (let i = 0; i < 10; i++) {
        container = container.parentElement;
        if (!container) break;

        // 寻找第一个 img 标签作为商品图片
        const img = container.querySelector('img[src]');
        if (img && img.src && !cardInfo.imageUrl) {
          cardInfo.imageUrl = img.src;
        }

        // 尝试从文本中获取标题
        const textContent = container.innerText || '';
        if (textContent.length > 5 && textContent.length < 500 && !cardInfo.title) {
          const lines = textContent.split('\n');
          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.length > 5 && trimmed.length < 200) {
              cardInfo.title = trimmed;
              break;
            }
          }
        }
      }

      return cardInfo;
    } catch (e) {
      console.error('[SPY] 提取卡片信息错误:', e);
      return { title: '', imageUrl: '', priceText: '' };
    }
  }

  /**
   * Mock 销冠数据获取函数
   * 模拟异步请求返回同类销量最高的商品数据
   */
  async function fetchBestSeller(itemId) {
    return new Promise((resolve) => {
      // 模拟网络延迟（300-800ms）
      const delay = 300 + Math.random() * 500;
      setTimeout(() => {
        // Mock 数据：返回随机销量和价格
        const mockSalesQty = Math.floor(1000 + Math.random() * 9000);
        const mockPrice = (2.5 + Math.random() * 8).toFixed(2);

        resolve({
          itemId,
          bestseller: {
            qty: mockSalesQty,
            price: mockPrice,
            rating: (3.8 + Math.random() * 1.2).toFixed(1)
          },
          timestamp: new Date().getTime()
        });
      }, delay);
    });
  }

  /**
   * 更新按钮显示销冠数据
   */
  function updateButtonWithBestseller(btn, data) {
    const qty = data.bestseller.qty;
    const price = data.bestseller.price;
    const rating = data.bestseller.rating;

    // 格式化销量
    let qtyLabel = qty >= 1000 ? (qty / 1000).toFixed(1) + 'k' : String(qty);

    // 更新按钮文本和样式
    btn.textContent = `📊 ${qtyLabel}单 $${price}`;
    btn.style.backgroundColor = '#2e7d32';
    btn.style.width = '110px';
    btn.title = `销冠: ${qty}单 | 价格: $${price} | 评分: ${rating}★`;
    btn.disabled = false;
  }

  /**
   * 显示错误信息
   */
  function showButtonError(btn, message) {
    btn.textContent = message;
    btn.style.backgroundColor = '#d32f2f';
    btn.disabled = false;
  }

  /**
   * 检查并扣减免费次数
   */
  function checkAndDeductFreeTrial(callback) {
    chrome.storage.local.get(
      {
        spy_user_token: null,
        free_trial_count: 0
      },
      (result) => {
        if (chrome.runtime.lastError) {
          callback(false, '存储访问错误');
          return;
        }

        // 已有会员
        if (result.spy_user_token) {
          callback(true, 'premium');
          return;
        }

        const currentCount = Number(result.free_trial_count) || 0;

        // 免费次数已用尽
        if (currentCount >= FREE_TRIAL_LIMIT) {
          callback(false, '您的免费次数已用完');
          return;
        }

        // 扣减一次
        const newCount = currentCount + 1;
        chrome.storage.local.set({ free_trial_count: newCount }, () => {
          callback(true, 'free', newCount, FREE_TRIAL_LIMIT);
        });
      }
    );
  }

  /**
   * 处理按钮点击 - 核心业务逻辑
   */
  function handleSpyButtonClick(btn, link, event) {
    // 阻止事件冒泡和默认跳转
    event.stopPropagation();
    event.preventDefault();

    // 获取卡片信息
    const cardInfo = extractCardInfo(link);
    const itemId = link.href.match(/\/item\/(\d+)/)?.[1];

    if (!itemId) {
      showButtonError(btn, '❌ 无法识别商品');
      return;
    }

    // 检查免费次数
    checkAndDeductFreeTrial((allowed, status, usedCount, limit) => {
      if (!allowed) {
        if (status === '您的免费次数已用完') {
          alert(
            '⚠️ 您的免费同类销冠透视额度已用完，请去右上角插件弹窗订阅 Premium 会员\n\n' +
            '✨ Premium 会员解锁全站无限次透视，享受专业数据分析服务'
          );
        } else {
          alert('⚠️ ' + status);
        }
        return;
      }

      // 显示加载中
      btn.textContent = '⏳ 加载中...';
      btn.style.backgroundColor = '#757575';
      btn.disabled = true;

      // 如果是免费用户，显示提示
      if (status === 'free') {
        const remaining = limit - usedCount;
        console.log(`[SPY] 免费试用次数: ${usedCount}/${limit}，还剩 ${remaining} 次`);
      }

      // 异步获取销冠数据
      fetchBestSeller(itemId)
        .then((data) => {
          if (data && data.bestseller) {
            productDataCache.set(itemId, data);
            updateButtonWithBestseller(btn, data);
          } else {
            showButtonError(btn, '❌ 获取数据失败');
          }
        })
        .catch((error) => {
          console.error('[SPY] 获取销冠数据错误:', error);
          showButtonError(btn, '❌ 请求异常');
        });
    });
  }

  /**
   * 绑定按钮事件（阻止冒泡）
   */
  function bindButtonEvents(btn, link) {
    // 使用捕获阶段阻止所有事件冒泡
    const preventBubble = (e) => {
      e.stopPropagation();
      e.preventDefault();
    };

    btn.addEventListener('click', (e) => {
      handleSpyButtonClick(btn, link, e);
    }, true);

    btn.addEventListener('mousedown', preventBubble, true);
    btn.addEventListener('mouseup', preventBubble, true);
    btn.addEventListener('dblclick', preventBubble, true);
    btn.addEventListener('contextmenu', preventBubble, true);
  }

  /**
   * 向单个商品链接注入透视按钮
   */
  function injectSpyButton(link) {
    // 检查是否已标记
    if (link.getAttribute(SPY_MARKED_ATTR) === '1') {
      return;
    }

    // 检查尺寸（避免过小的链接）
    if (link.clientWidth < MIN_LINK_WIDTH || link.clientHeight < MIN_LINK_HEIGHT) {
      return;
    }

    // 强制设置链接为相对定位（绝对定位参考）
    link.style.setProperty('position', 'relative', 'important');

    // 创建按钮
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = SPY_BTN_CLASS;
    btn.textContent = '🔍 查看销冠';
    btn.setAttribute('aria-label', '查看同类销冠数据');

    // 应用样式
    Object.keys(BTN_STYLES).forEach((key) => {
      btn.style[key] = BTN_STYLES[key];
    });

    // 绑定事件
    bindButtonEvents(btn, link);

    // 追加到链接
    link.appendChild(btn);

    // 标记已注入
    link.setAttribute(SPY_MARKED_ATTR, '1');
  }

  /**
   * 全网盲扫所有商品链接并注入按钮
   */
  function scanAndInjectAll() {
    const links = document.querySelectorAll('a[href*="/item/"]');
    console.log(`[SPY] 扫描到 ${links.length} 个商品链接`);

    links.forEach((link) => {
      try {
        injectSpyButton(link);
      } catch (e) {
        console.error('[SPY] 注入按钮错误:', e);
      }
    });
  }

  /**
   * 监听 DOM 变化（新商品加载）
   */
  function observeDomMutations() {
    const observer = new MutationObserver(() => {
      // 延迟执行，避免频繁扫描
      clearTimeout(observeDomMutations.debounceTimer);
      observeDomMutations.debounceTimer = setTimeout(() => {
        scanAndInjectAll();
      }, 300);
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: false
    });
  }

  /**
   * 初始化插件
   */
  function init() {
    console.log('[SPY] 销冠透视插件 v2.0 已加载');

    // 首次扫描
    scanAndInjectAll();

    // 监听 DOM 变化
    observeDomMutations();

    // 定期扫描（保险机制）
    setInterval(() => {
      scanAndInjectAll();
    }, SCAN_INTERVAL_MS);
  }

  // 页面加载完成后启动
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
