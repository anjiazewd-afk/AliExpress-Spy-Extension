/**
 * AliExpress 爆款雷达 Spy — Page Hook (MAIN world)
 * 拦截速卖通 MTOP 接口 + 按需拉取 PDP 详情，获取真实销量/评分
 */
(function () {
  'use strict';

  if (window.__AE_SPY_HOOKED__) return;
  window.__AE_SPY_HOOKED__ = true;

  const APP_KEY = '12574478';
  const productCache = new Map();

  /* ── MD5（MTOP 签名必需） ── */
  function md5(str) {
    function cmn(q, a, b, x, s, t) {
      a = (a + q + x + t) | 0;
      return (((a << s) | (a >>> (32 - s))) + b) | 0;
    }
    function ff(a, b, c, d, x, s, t) { return cmn((b & c) | (~b & d), a, b, x, s, t); }
    function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & ~d), a, b, x, s, t); }
    function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
    function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | ~d), a, b, x, s, t); }

    function md5blk(s) {
      const blks = [];
      for (let i = 0; i < 64; i += 4) {
        blks[i >> 2] =
          s.charCodeAt(i) |
          (s.charCodeAt(i + 1) << 8) |
          (s.charCodeAt(i + 2) << 16) |
          (s.charCodeAt(i + 3) << 24);
      }
      return blks;
    }

    function md51(s) {
      const n = s.length;
      const blks = md5blk(s.slice(0, 64));
      let a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;

      for (let i = 0; i < n; i += 64) {
        const x = i === 0 ? blks : md5blk(s.slice(i, i + 64));
        let oa = a, ob = b, oc = c, od = d;

        a = ff(a, b, c, d, x[0], 7, -680876936);
        d = ff(d, a, b, c, x[1], 12, -389564586);
        c = ff(c, d, a, b, x[2], 17, 606105819);
        b = ff(b, c, d, a, x[3], 22, -1044525330);
        a = ff(a, b, c, d, x[4], 7, -176418897);
        d = ff(d, a, b, c, x[5], 12, 1200080426);
        c = ff(c, d, a, b, x[6], 17, -1473231341);
        b = ff(b, c, d, a, x[7], 22, -45705983);
        a = ff(a, b, c, d, x[8], 7, 1770035416);
        d = ff(d, a, b, c, x[9], 12, -1958414417);
        c = ff(c, d, a, b, x[10], 17, -42063);
        b = ff(b, c, d, a, x[11], 22, -1990404162);
        a = ff(a, b, c, d, x[12], 7, 1804603682);
        d = ff(d, a, b, c, x[13], 12, -40341101);
        c = ff(c, d, a, b, x[14], 17, -1502002290);
        b = ff(b, c, d, a, x[15], 22, 1236535329);

        a = gg(a, b, c, d, x[1], 5, -165796510);
        d = gg(d, a, b, c, x[6], 9, -1069501632);
        c = gg(c, d, a, b, x[11], 14, 643717713);
        b = gg(b, c, d, a, x[0], 20, -373897302);
        a = gg(a, b, c, d, x[5], 5, -701558691);
        d = gg(d, a, b, c, x[10], 9, 38016083);
        c = gg(c, d, a, b, x[15], 14, -660478335);
        b = gg(b, c, d, a, x[4], 20, -405537848);
        a = gg(a, b, c, d, x[9], 5, 568446438);
        d = gg(d, a, b, c, x[14], 9, -1019803690);
        c = gg(c, d, a, b, x[3], 14, -187363961);
        b = gg(b, c, d, a, x[8], 20, 1163531501);
        a = gg(a, b, c, d, x[13], 5, -1444681467);
        d = gg(d, a, b, c, x[2], 9, -51403784);
        c = gg(c, d, a, b, x[7], 14, 1735328473);
        b = gg(b, c, d, a, x[12], 20, -1926607734);

        a = hh(a, b, c, d, x[5], 4, -378558);
        d = hh(d, a, b, c, x[8], 11, -2022574463);
        c = hh(c, d, a, b, x[11], 16, 1839030562);
        b = hh(b, c, d, a, x[14], 23, -35309556);
        a = hh(a, b, c, d, x[1], 4, -1530992060);
        d = hh(d, a, b, c, x[4], 11, 1272893353);
        c = hh(c, d, a, b, x[7], 16, -155497632);
        b = hh(b, c, d, a, x[10], 23, -1094730640);
        a = hh(a, b, c, d, x[13], 4, 681279174);
        d = hh(d, a, b, c, x[0], 11, -358537222);
        c = hh(c, d, a, b, x[3], 16, -722521979);
        b = hh(b, c, d, a, x[6], 23, 76029189);
        a = hh(a, b, c, d, x[9], 4, -640364487);
        d = hh(d, a, b, c, x[12], 11, -421815835);
        c = hh(c, d, a, b, x[15], 16, 530742520);
        b = hh(b, c, d, a, x[2], 23, -995338651);

        a = ii(a, b, c, d, x[0], 6, -198630844);
        d = ii(d, a, b, c, x[7], 10, 1126891415);
        c = ii(c, d, a, b, x[14], 15, -1416354905);
        b = ii(b, c, d, a, x[5], 21, -57434055);
        a = ii(a, b, c, d, x[12], 6, 1700485571);
        d = ii(d, a, b, c, x[3], 10, -1894986606);
        c = ii(c, d, a, b, x[10], 15, -1051523);
        b = ii(b, c, d, a, x[1], 21, -2054922799);
        a = ii(a, b, c, d, x[8], 6, 1873313359);
        d = ii(d, a, b, c, x[15], 10, -30611744);
        c = ii(c, d, a, b, x[6], 15, -1560198380);
        b = ii(b, c, d, a, x[13], 21, 1309151649);
        a = ii(a, b, c, d, x[4], 6, -145523070);
        d = ii(d, a, b, c, x[11], 10, -1120210379);
        c = ii(c, d, a, b, x[2], 15, 718787259);
        b = ii(b, c, d, a, x[9], 21, -343485551);

        a = (a + oa) | 0;
        b = (b + ob) | 0;
        c = (c + oc) | 0;
        d = (d + od) | 0;
      }
      return [a, b, c, d];
    }

    function rhex(n) {
      let s = '';
      for (let j = 0; j < 4; j++) {
        s += ('0' + ((n >> (j * 8)) & 255).toString(16)).slice(-2);
      }
      return s;
    }

    const x = md51(unescape(encodeURIComponent(str)));
    return rhex(x[0]) + rhex(x[1]) + rhex(x[2]) + rhex(x[3]);
  }

  function getCookie(name) {
    const m = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : '';
  }

  function parseTradeDesc(text) {
    if (!text || typeof text !== 'string') return null;
    const m = text.match(/([\d,.]+)\s*([kK])?\+?/);
    if (!m) return null;
    let n = parseFloat(m[1].replace(/,/g, ''));
    if (m[2]) n *= 1000;
    return Number.isFinite(n) ? Math.round(n) : null;
  }

  function normalizeProduct(itemId, sales, rating, source) {
    if (sales == null && rating == null) return null;
    return {
      itemId: String(itemId),
      sales: sales != null ? Number(sales) : null,
      rating: rating != null ? Number(parseFloat(rating).toFixed(1)) : null,
      source: source || 'unknown'
    };
  }

  function cacheAndBroadcast(data) {
    if (!data || !data.itemId) return;
    productCache.set(data.itemId, data);
    document.dispatchEvent(new CustomEvent('ae-spy-product-cached', { detail: data }));
  }

  /** 从 JSON 递归提取商品销量/评分 */
  function extractFromJson(obj, found) {
    if (!obj || typeof obj !== 'object') return;

    if (Array.isArray(obj)) {
      obj.forEach((item) => extractFromJson(item, found));
      return;
    }

    const rawId = obj.productId ?? obj.itemId ?? obj.id ?? obj.goodsId;
    const idStr = rawId != null ? String(rawId) : null;

    if (idStr && /^\d{8,}$/.test(idStr)) {
      const sales =
        obj.soldCount ??
        obj.orders ??
        obj.orderCount ??
        obj.tradeCount ??
        parseTradeDesc(obj.trade?.tradeDesc) ??
        parseTradeDesc(obj.tradeDesc);

      const rating =
        obj.evaluation?.starRating ??
        obj.starRating ??
        obj.averageStar ??
        obj.tradeScore ??
        obj.feedbackRating?.averageStar;

      const normalized = normalizeProduct(idStr, sales, rating, 'intercept');
      if (normalized) {
        found.set(idStr, normalized);
        cacheAndBroadcast(normalized);
      }
    }

    Object.keys(obj).forEach((key) => extractFromJson(obj[key], found));
  }

  function tryParseResponseText(text) {
    if (!text || text[0] !== '{' && text[0] !== '[') return;
    try {
      const json = JSON.parse(text);
      extractFromJson(json, new Map());
    } catch (_) {
      /* 非 JSON 忽略 */
    }
  }

  function shouldInterceptUrl(url) {
    if (!url || typeof url !== 'string') return false;
    return (
      url.includes('aliexpress') &&
      (url.includes('mtop') || url.includes('/h5/') || url.includes('recommend') || url.includes('search'))
    );
  }

  /** Hook fetch */
  const origFetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await origFetch.apply(this, args);
    try {
      const url = typeof args[0] === 'string' ? args[0] : args[0]?.url;
      if (shouldInterceptUrl(url)) {
        const clone = response.clone();
        clone.text().then(tryParseResponseText).catch(() => {});
      }
    } catch (_) {}
    return response;
  };

  /** Hook XMLHttpRequest */
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__aeSpyUrl = url;
    return origOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    this.addEventListener('load', function () {
      try {
        if (shouldInterceptUrl(this.__aeSpyUrl)) {
          tryParseResponseText(this.responseText);
        }
      } catch (_) {}
    });
    return origSend.apply(this, args);
  };

  async function mtopRequest(api, version, data) {
    const t = Date.now();
    const dataStr = JSON.stringify(data);
    const token = (getCookie('_m_h5_tk') || getCookie('_m_h5_tk_enc') || '').split('_')[0];
    const sign = md5(token + '&' + t + '&' + APP_KEY + '&' + dataStr);

    const params = new URLSearchParams({
      jsv: '2.7.2',
      appKey: APP_KEY,
      t: String(t),
      sign,
      api,
      v: version,
      type: 'originaljson',
      dataType: 'json',
      data: dataStr
    });

    const url = 'https://acs.aliexpress.com/h5/' + api + '/' + version + '/?' + params.toString();
    const res = await origFetch(url, { credentials: 'include', method: 'GET' });
    return res.json();
  }

  /** 解析 PDP MTOP 响应 */
  function parseMtopPdp(json) {
    const root = json?.data?.result ?? json?.data ?? json?.result ?? json;
    if (!root || typeof root !== 'object') return null;

    const feedback = root.feedbackModule ?? root.FEEDBACK_PC ?? root.feedback ?? {};
    const quantity = root.QUANTITY_PC ?? root.quantityModule ?? root.trade ?? {};
    const header = root.HEADER_PC_V2 ?? root.headerModule ?? {};

    const sales =
      quantity.soldCount ??
      quantity.totalSold ??
      feedback.tradeCount ??
      parseTradeDesc(quantity.tradeDesc) ??
      parseTradeDesc(feedback.tradeDesc);

    const rating =
      feedback.tradeScore ??
      feedback.averageStar ??
      header.feedbackRating?.averageStar ??
      header.averageStar;

    const productId =
      root.productId ??
      root.goodsId ??
      json?.data?.productId;

    return normalizeProduct(productId, sales, rating, 'mtop-pdp');
  }

  async function fetchProductViaMtop(productId) {
    const locale = document.documentElement.lang || 'en_US';
    const configs = [
      {
        api: 'mtop.aliexpress.pdp.pc.query',
        v: '1.0',
        data: { productId, _lang: locale, country: 'US', locale, channel: 'seo' }
      },
      {
        api: 'mtop.aliexpress.pcdetail.data.get',
        v: '1.0',
        data: {
          productId,
          lang: locale,
          country: 'US',
          currency: 'USD',
          province: '',
          city: '',
          channel: '',
          pdp_ext_f: ''
        }
      }
    ];

    for (const cfg of configs) {
      try {
        const json = await mtopRequest(cfg.api, cfg.v, cfg.data);
        const parsed = parseMtopPdp(json);
        if (parsed && parsed.itemId) return parsed;
        if (parsed) {
          parsed.itemId = String(productId);
          return parsed;
        }
      } catch (_) {}
    }
    return null;
  }

  /** content script 按需拉取 */
  document.addEventListener('ae-spy-fetch-request', async (e) => {
    const itemId = e.detail?.itemId;
    if (!itemId) return;

    let data = productCache.get(String(itemId));
    if (!data) {
      data = await fetchProductViaMtop(itemId);
      if (data) cacheAndBroadcast(data);
    }

    document.dispatchEvent(
      new CustomEvent('ae-spy-fetch-response', {
        detail: data || { itemId: String(itemId), sales: null, rating: null, source: 'failed' }
      })
    );
  });

  /** 暴露缓存供调试 */
  window.__AE_SPY_CACHE__ = productCache;
})();
